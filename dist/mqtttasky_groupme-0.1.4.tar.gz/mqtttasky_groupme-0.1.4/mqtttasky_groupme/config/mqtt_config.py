CONFIG = {
    'port': 1883,
    'host': '',
    'username': '',
    'password': '',
    'cipher_key': ''
}
